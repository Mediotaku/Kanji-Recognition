function y = hello_world %#codegen

y = 'Hello World!';

end
%   Copyright 2010 The MathWorks, Inc.
